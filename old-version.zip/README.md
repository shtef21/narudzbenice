# Narudzbenice

Za pokretanje aplikacije potrebno je:

- Instalirati Node JS (npr verziju 18.19.1)

- Pokrenuti npm install

- Pokrenuti Narudzbenice.bat na Windowsu ili Narudzbenice.sh na Linuxu
